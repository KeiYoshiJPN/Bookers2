# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end

Refile.secret_key = '5c4ade9b1ed41a11aa5cecdd4770fd776569f81c26cb1009779b355391d54c720be5a5c31ca63b8d2f6f34870b7970e7f7871705bd84c6526e89b0e757128374'